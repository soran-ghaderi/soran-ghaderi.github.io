module ModernResumeTheme
  VERSION = "1.8.9"
end
